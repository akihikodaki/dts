#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2021 PANTHEON.tech s.r.o.

import os

print(os.cpu_count())
