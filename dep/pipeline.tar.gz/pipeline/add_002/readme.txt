Test Case: test_add_002
-----------------------

    Instruction being tested:
        add h.field h.field

    Description:
        For the received packet add source MAC address to the destination MAC address and transmit it back on the same port.

    Verification:
        Destination MAC address of the transmitted packet should be the sum of source and destination MAC addresses of the received packet.
