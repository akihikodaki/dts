
Test Case: test_and_005
-----------------------

    Instruction being tested:
        and h.field m.field

    Description:
        For the received packet, bitwise AND destination MAC address,
        destination IP address and IP identification with a fixed value and
        transmit the packet back on the same port.

    Verification:
        Verify using input and output pcap files.
