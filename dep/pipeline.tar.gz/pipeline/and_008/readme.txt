Test Case: test_and_008
-----------------------

    Instructions being tested:
	and h.field t.field

    Description:
	For a packet with matching destination MAC address, source MAC address will be logically AND with the entry in the table.

    Verification:
	Packet will be received on the same port and source MAC address will be logically and with table entry.
	
