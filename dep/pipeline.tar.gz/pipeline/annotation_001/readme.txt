Test Case: test_annotation_001
-----------------------

    Scenario being tested:
        SPEC file contains more than one correctly defined defaultonly and tableonly annotations.
        The tableonly actions mentioned in the SPEC file are listed/configured properly in rule file.
        The application should run without any errors and packet verification must happen accordingly.


    Verification:
        Packet should get verified according to configured rules in the rule file.
