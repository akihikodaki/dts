Test Case: test_annotation_003
-----------------------

    Scenario being tested:
        Amongst all the listed actions in SPEC file, one action is annoted twice.

    Verification:
        Application should not run and throw error
        "Error -22 at line xx: Invalid action name statement."
