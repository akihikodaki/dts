Test Case: test_annotation_004
-----------------------

    Scenario being tested:
        Adding rule to a defaultonly annotated default action

    Verification:
        Application should not run and throw error
        "Invalid entry in file /tmp/pipeline/annotation_004/annotation_004_table.txt at line xx"
