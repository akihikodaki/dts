Test Case: test_dma_001
-----------------------

    Instructions being tested:
        dma h.header t.field

    Description:
	Based on the destination MAC address of the received packet, ethernet header is updated from the table.

    Verification:
	Transmitted packet should have the ethernet header as defined in the table.
