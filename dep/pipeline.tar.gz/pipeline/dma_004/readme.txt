Test Case: test_dma_004
-----------------------
    Instructions being tested:
        dma h.header t.field (level 4)

    Description:
        Based on the destination MAC address of the received packet ethernet, VLAN, IPv4 and TCP headers are updated from the table.

    Verification:
        Transmitted packet should have the ethernet, VLAN, IPv4 and TCP headers as defined in the table.
