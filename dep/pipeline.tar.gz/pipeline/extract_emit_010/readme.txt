Test Case: test_extract_emit_010
--------------------------------
    Instructions being tested:
        extract h.field
        emit h.field

    Description:
        Testcase will verify invalidating outer most header from the packet.

    Verification:
        The received packet will have outer most header removed from the packet.
