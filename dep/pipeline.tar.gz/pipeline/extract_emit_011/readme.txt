Test Case: test_extract_emit_011
--------------------------------
    Instructions being tested:
        extract h.field
        emit h.field

    Description:
        Testcase will verify invalidating second header of the packet.

    Verification:
        The received packet will have second header removed from the packet.
