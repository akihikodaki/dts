Test Case: test_extract_emit_012
--------------------------------
    Instructions being tested:
        extract h.field
        emit h.field

    Description:
        The test will verify invalidating all headers. The received packet should have load content.

    Verification:
        The received packet whould have load content.
