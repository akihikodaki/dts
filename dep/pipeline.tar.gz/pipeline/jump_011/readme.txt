Test Case: test_jump_011
------------------------
    Instructions being tested:
        jmplt LABEL h.field h.field

    Description:
        For the received packet, if source MAC address is less than destination MAC address, transmit the packet back on the same port,
        else drop it.

    Verification:
        Only packets having source MAC address lesser than destination MAC address will be transmitted. Other packets should be dropped.
