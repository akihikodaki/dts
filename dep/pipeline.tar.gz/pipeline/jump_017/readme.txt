Test Case: test_jump_017
------------------------
    Instructions being tested:
        jmpgt LABEL h.field h.field

    Description:
        For the received packet, if destination MAC address is greater than source MAC address, transmit the packet back on the same port,
        else drop it.

    Verification:
        Only packets having destination MAC address greater than source MAC address will be transmitted. Other packets should be dropped.
