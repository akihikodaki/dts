Test Case: test_jump_020
------------------------

    Instructions being tested:
        jmpeq LABEL h.field h.field

    Description:
        For the received packet, if it has matching source and destination ipv4 address, transmit it as it is back on the same port. For
        packets with differing source and destination ipv4 addresses, swap their MAC addresses.

    Verification:
        Behavior should be as per the description.
