Test Case: test_jump_021
------------------------

    Instructions being tested:
        jmpeq LABEL h.field m.field

    Description:
        For the received packet, if it has ether type equal to 0x0800, transmit it as it is back on the same port. Drop all other packets.

    Verification:
        Packets with ether type as 0x0800 should be transmitted as it is back on same port. All other packets should be dropped.
