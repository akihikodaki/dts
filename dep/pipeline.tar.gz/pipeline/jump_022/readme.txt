Test Case: test_jump_022
------------------------

    Instructions being tested:
        jmpeq LABEL m.field h.field

    Description:
        For the received packet, if the protocol field of ipv4 packet is equal to tcp, transmit it as it is back on the same port. Drop all
        other packets.

    Verification:
        Packets with ipv4 protocol field equal to tcp should be transmitted as it is back on same port. All other packets should be dropped.
