Test Case: test_jump_027
-----------------------

    Instructions being tested:
	 jmpeq LABEL t.field m.field


	Description
	In this testcase, on the basis of ethernet dst mac address, if the packet ether type is equal to the corrosponding entry in the table then packet is transmitted else packet is dropped.
	Verification
	Behavior should be as per the description.
