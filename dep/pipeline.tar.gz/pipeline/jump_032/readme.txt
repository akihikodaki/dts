Test Case: test_jump_032
-----------------------

    Instruction being tested:
        jmpneq LABEL h.field h.field

    Description:
        If source and destination MAC addresses are different, then transmit it as it is back on the same port. Else drop the packet.

    Verification:
        Behavior should be as per the description.
