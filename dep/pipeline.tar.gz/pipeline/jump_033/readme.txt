Test Case: test_jump_033
------------------------

    Instructions being tested:
        jmpneq LABEL h.field m.field

    Description:
        Drop all the packets with ttl value equal to zero. For others, decrement ttl by one and transmit it back on the same port.

    Verification:
        Packets with ttl value equal to zero should be dropped and others should be transmitted back with ttl decremented by one.
