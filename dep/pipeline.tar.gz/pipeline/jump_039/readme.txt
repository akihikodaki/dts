Test Case: test_jump_039
-----------------------

    Instructions being tested:
	 jmpneq LABEL t.field m.field


	Description
	In this testcase, on the basis of ethernet dst mac address, if the packet ether type is not equal to the corrosponding entry in the table then packet is transmitted else packet is dropped.
	Verification
	Behavior should be as per the description.
