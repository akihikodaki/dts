Test Case: test_learner_005
-----------------------

    Instruction being tested:
        learner TABLE_NAME (default_action ACTION_NAME args none | ARGS_BYTE_ARRAY [ const ])

    Description:
		The testcase will verify the default action. In this testcase, default action of
		the table is updated at runtime.

    Verification:
        Simulate the test as per the description. Behaviour should be as described.
