Test Case: test_mov_001
-----------------------

    Instruction being tested:
        mov h.field h.field

    Description:
        Copy the destination MAC address of the received packet into the source MAC address field and transmit the packet back on the same port.

    Verification:
        Source and destination MAC address fields of the received  packet should have same value.
