
Test Case: test_mov_002
-----------------------

	Instructions being tested:
		mov m.field h.field
		mov h.field m.field

	Description:
		Swap the source and destination IP address of the received packet and
		transmit the packet back on the same port.

	Verification:
		To be verified using input & output pcap files.
