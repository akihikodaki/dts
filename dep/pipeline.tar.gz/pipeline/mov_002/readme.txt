Test Case: test_mov_002
-----------------------

    Instructions being tested:
        mov m.field h.field
	mov h.field m.field

    Description:
	Swap the source and destination MAC address of the received packet and transmit the packet back on the same port.

    Verification:
	Source and destination MAC address fields of the received packet are swapped.
