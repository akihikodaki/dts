Test Case: test_mov_004
-----------------------

    Instructions being tested:
	mov h.field t.field

	In this testcase, we will first find entry in the table based on the des mac address, then update the src mac address to the mac address in the table.
