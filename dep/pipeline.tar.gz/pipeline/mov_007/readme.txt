Test Case: test_mov_007
-----------------------

    Instructions being tested:
        mov m.field immediate_data

    Description:
	Update the output port value in the meta data field with a fix value.

    Verification:
	Packet should be received on the hard coded port mentioned in the spec file.

