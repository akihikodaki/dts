
Test Case: test_mov_007
-----------------------

	Instructions being tested:
		mov m.field immediate_data

	Description:
		Update the destination MAC address, destination IP address and IP
		identification fields of the input packet with fixed values using this
		instruction.

	Verification:
		Verify using input and output pcap files.
