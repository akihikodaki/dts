Test Case: test_mov_008
-----------------------

    Instructions being tested:
        mov h.field immediate_data

    Description:
	 Update the IP source address to fixed value.

    Verification:
	Received packet will have IP address hard coded in the spec file.


