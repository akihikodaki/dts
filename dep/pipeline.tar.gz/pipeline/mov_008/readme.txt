
Test Case: test_mov_008
-----------------------

	Instructions being tested:
		mov h.field immediate_data

	Description:
		Update the destination MAC address, destination IP address and IP
		identification of the received packet to a fixed value.

	Verification:
		Verify using input and output pcap files.
