Test Case: test_or_001
-----------------------

    Instructions being tested:
	or h.field t.field

    Description:
	For a packet with matching destination MAC address, bitwise OR the MAC source address with the value stored in the table and send the updated MAC source address packet to the same port.

    Verification:
	Received packet should have ethernet MAC address ORed value of transmitted MAC src address and masked value stored in the table.
