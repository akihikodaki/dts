Test Case: test_shl_002
-------------------------

    Instructions being tested:
        shl m.field h.field

    Description:
        For the received packet, left shift the destination MAC address by the value present in the diffserv field of ipv4 header and transmit the packet
        back on the same port.

    Verification:
        Destination MAC address of the transmitted packet should be shifted left by the value present in the diffserv field of ipv4 header with respect to
        the destination MAC address of the received packet.
