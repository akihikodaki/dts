Test Case: test_shl_008
-----------------------

    Instructions being tested:
	shl m.field t.field

	Description:
	For a packet with matching destination IP address, TTL value is shifted left by the amount mentioned in the table.
	
	Verification:
	TTL value of the received packet will be shifted left by the value mentioned in the table.
