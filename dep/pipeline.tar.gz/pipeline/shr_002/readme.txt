Test Case: test_shr_002
-----------------------

    Instructions being tested:
        shr m.field h.field

    Description:
        For the received packet, right shift the destination MAC address by the value present in the diffserv field of ipv4 header and transmit the packet
        back on the same port.

    Verification:
        Destination MAC address of the transmitted packet should be shifted right by the value present in the diffserv field of ipv4 header with respect to
        the destination MAC address of the received packet.
