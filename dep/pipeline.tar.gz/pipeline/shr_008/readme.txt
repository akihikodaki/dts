Test Case: test_shr_008
-----------------------

    Instructions being tested:
	shr m.field t.field

    Description:
	For a packet with matching destination IP address, TTL value is shifted right by the amount mentioned in the table.	

    Verification:
	TTL value of the received packet will be shifted right by the value mentioned in the table.
