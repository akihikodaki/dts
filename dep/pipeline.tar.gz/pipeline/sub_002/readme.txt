Test Case: test_sub_002
-----------------------

    Instruction being tested:
        sub h.field h.field

    Description:
        For the received packet, subtract source MAC address from the destination MAC address and transmit it back on the same port.

    Verification:
        Destination MAC address of the transmitted packet should be the difference of destination and source MAC addresses respectively
        of the received packet.
