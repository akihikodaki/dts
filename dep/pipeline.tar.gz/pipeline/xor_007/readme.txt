Test Case: test_xor_007
-----------------------

    Instructions being tested:
	xor h.field t.field

    Description:
	For a packet with matching destination MAC address, logically inverted the MAC source address using the xor opertation. 

    Verification:
	Packet will be received on the same port and ethernet MAC address will be logically not of the input MAC source address.
